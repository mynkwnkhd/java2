package pages;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class TestInputsServlet
 */
@WebServlet("/test2")
public class TestInputsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		try(PrintWriter pw=response.getWriter())
		{
			pw.print("<h4>Name : "+request.getParameter("f1")+"<h4>");
			pw.print("<h4>PWD : "+request.getParameter("f2")+"<h4>");
			pw.print("<h4>Favourite Clrs : "+Arrays.toString(request.getParameterValues("clr"))+"<h4>");
			pw.print("<h4>Chosen Browser  : "+request.getParameter("browser")+"<h4>");
			pw.print("<h4>Number  : "+request.getParameter("myselect")+"<h4>");
			pw.print("<h4>Join date : "+request.getParameter("join_dt")+"<h4>");
			pw.print("<h4>Amount  : "+request.getParameter("amt")+"<h4>");
	

		}
	}

}
